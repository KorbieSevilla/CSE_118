package com.example.rentadriveway;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import android.content.SharedPreferences;


public class signUpActivity extends AppCompatActivity {

    EditText userName, email, password, phone;
    Button finished;
    SharedPreferences userInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        userName = findViewById(R.id.userName);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        phone = findViewById(R.id.phone);
        finished = findViewById(R.id.finished);
        userInfo = getSharedPreferences("User Info", MODE_PRIVATE);

    }

    @Override
    protected void onResume() {
        super.onResume();
        finished.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String uN = "";
                String em = "";
                String pw = "";
                String ph = "";
                if(!userName.getText().toString().isEmpty()){
                    uN = userName.getText().toString();
                }
                if(!email.getText().toString().isEmpty()){
                    em = email.getText().toString();
                }
                if(!password.getText().toString().isEmpty()){
                    pw = password.getText().toString();
                }
                if(!phone.getText().toString().isEmpty()){
                    ph = phone.getText().toString();
                }

                String info = uN + " : " + em + " : " + pw + " : " + ph;


                SharedPreferences.Editor editor = userInfo.edit();

                editor.putString(uN, info);
                editor.apply();

                Intent ud = new Intent(signUpActivity.this, userData.class);
                startActivity(ud);
            }
        });
    }

}
